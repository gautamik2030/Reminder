package com.example.reminder_application;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.Toast;


import java.util.Locale;

import static android.content.Context.ALARM_SERVICE;
import static android.content.Context.MODE_PRIVATE;

public class HomeFragment extends Fragment {


    //TextView breakTime;

    CountDownTimer mCountDownTimer;
    boolean mTimerRunning;
    long mStartTimeInMillis;
    long mTimeLeftInMillis;
    long mEndTime;
    int notificationId = 1;
    long brStartTime, brEndtime, drStartTime, drEndTime;
    long drinks,drinke;

    Button refresh;
    long breaktime;

    CountDownTimer mCountDownTimer1;
    boolean mTimerRunning1;
    long mStartTimeInMillis1;
    long mTimeLeftInMillis1;
    long mEndTime1;

    ProgressBar progressBar;
    TextView litresintake,breakTime;
    DBHelper db;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home,container,false);
        progressBar=view.findViewById(R.id.progressBar);
        litresintake=view.findViewById(R.id.litresintake);

        refresh = view.findViewById(R.id.refresh);


        breakTime=view.findViewById(R.id.breakTime);



        db = new DBHelper(getActivity());
        Cursor present=db.getData();

        if(present.getCount()>0)
        {

            present.moveToFirst();
            int g = present.getInt(present.getColumnIndex("goal"));
            int c = present.getInt(present.getColumnIndex("current"));
            int gc=g-c;


            String gs=Integer.toString(g);

            String cs = Integer.toString(gc);
            String s = cs+" of "+gs+" ";
            litresintake.setText(s);


            double progress = c/g;
            int p= (int) (progress* 100);
            progressBar.setProgress(p);


            refresh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    db = new DBHelper(getActivity());
                    Cursor present1 = db.getData();

                    if (present1.getCount() > 0) {

                        present1.moveToFirst();
                        int g = present1.getInt(present1.getColumnIndex("goal"));
                        int c = present1.getInt(present1.getColumnIndex("current"));
                        int gc = g - c;


                        String gs = Integer.toString(g);

                        String cs = Integer.toString(gc);
                        String s = cs + " of " + gs + " ";
                        litresintake.setText(s);


                        double progress = c / g;
                        int p = (int) (progress * 100);
                        progressBar.setProgress(p);
                    }
                }
            });


//            int brtime = db.getItimeBreak();
//
//            breaktime = brtime* 60000;
//            brStartTime = db.getSTimeBreak();
//            brEndtime = db.getEtimeBreak();
        }







        return view;
    }


    private void startTimer() {
        mEndTime = System.currentTimeMillis() + mTimeLeftInMillis;
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateCountDownText();
            }
            @Override
            public void onFinish() {
                mTimerRunning = false;
                resetTimer();

            }
        }.start();
        mTimerRunning = true;
    }

    private void startTimer1() {
        mEndTime1 = System.currentTimeMillis() + mTimeLeftInMillis1;
        mCountDownTimer1 = new CountDownTimer(mTimeLeftInMillis1, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis1 = millisUntilFinished;

            }
            @Override
            public void onFinish() {
                mTimerRunning1= false;
                resetTimer1();

            }
        }.start();
        mTimerRunning1 = true;
    }


    private void resetTimer1() {
        mTimeLeftInMillis1 = mStartTimeInMillis1;
        startTimer();

        notific1 ();

    }
    private void updateCountDownText() {
        int hours = (int) (mTimeLeftInMillis / 1000) / 3600;
        int minutes = (int) ((mTimeLeftInMillis / 1000) % 3600) / 60;
        int seconds = (int) (mTimeLeftInMillis / 1000) % 60;
        String timeLeftFormatted;
        if (hours > 0) {
            timeLeftFormatted = String.format(Locale.getDefault(),
                    "%d:%02d:%02d", hours, minutes, seconds);
        } else {
            timeLeftFormatted = String.format(Locale.getDefault(),
                    "%02d:%02d", minutes, seconds);
        }
        breakTime.setText(timeLeftFormatted);
    }

    private void setTime(long milliseconds) {
        mStartTimeInMillis = milliseconds;
        resetTimer();
    }
    private void resetTimer() {
        mTimeLeftInMillis = mStartTimeInMillis;
        updateCountDownText();
        startTimer();

       notific ();

    }


    private void pauseTimer() {
        mCountDownTimer.cancel();
        mTimerRunning = false;
        //updateWatchInterface();
    }

    @Override

    public void onStart() {
        super.onStart();

        SharedPreferences prefs = this.getActivity().getSharedPreferences("prefs", MODE_PRIVATE);
        mStartTimeInMillis = prefs.getLong("startTimeInMillis", 60000);
        mTimeLeftInMillis = prefs.getLong("millisLeft", mStartTimeInMillis);
        mTimerRunning = prefs.getBoolean("timerRunning", false);


        SharedPreferences prefse = this.getActivity().getSharedPreferences("prefse", MODE_PRIVATE);
        mStartTimeInMillis1 = prefs.getLong("startTimeInMillis1", 60000);
        mTimeLeftInMillis1 = prefs.getLong("millisLeft1", mStartTimeInMillis);
        mTimerRunning1 = prefs.getBoolean("timerRunning1", false);

        updateCountDownText();
        //updateWatchInterface();

        boolean x;


        db = new DBHelper(getActivity());
        Cursor present1 = db.getData();

        if (present1.getCount() > 0) {

            present1.moveToFirst();
            int g = present1.getInt(present1.getColumnIndex("goal"));
            int c = present1.getInt(present1.getColumnIndex("current"));
            int gc = g - c;


            String gs = Integer.toString(g);

            String cs = Integer.toString(gc);
            String s = cs + " of " + gs + " ";
            litresintake.setText(s);


            double progress = c / g;
            int p = (int) (progress * 100);
            progressBar.setProgress(p);
        }

        long time = System.currentTimeMillis();
        drStartTime = 600;
        drEndTime=  1320;
        drinks = drStartTime * 60000;
        drinke = drEndTime * 60000;


//        setTime(breaktime);
//
//        if(time <= brStartTime  && time>= brEndtime){
            startTimer();

        startTimer1();
            //resetTimer();
       // }
        if (mTimerRunning) {
            mEndTime = prefs.getLong("endTime", 0);
            mTimeLeftInMillis = mEndTime - System.currentTimeMillis();
            if (mTimeLeftInMillis < 0) {
                mTimeLeftInMillis = 0;
                mTimerRunning = false;
                updateCountDownText();
                //updateWatchInterface();
            } else {
                startTimer();
            }
        }


        if (mTimerRunning1) {
            mEndTime1 = prefse.getLong("endTime1", 0);
            mTimeLeftInMillis1 = mEndTime1 - System.currentTimeMillis();
            if (mTimeLeftInMillis1 < 0) {
                mTimeLeftInMillis1 = 0;
                mTimerRunning1 = false;
                //updateWatchInterface();
            } else {
                startTimer();
            }
        }


    }

    @Override
    public void onStop() {
        super.onStop();
        SharedPreferences prefs = this.getActivity().getSharedPreferences("prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong("startTimeInMillis", mStartTimeInMillis);
        editor.putLong("millisLeft", mTimeLeftInMillis);
        editor.putBoolean("timerRunning", mTimerRunning);
        editor.putLong("endTime", mEndTime);
        editor.apply();
        if (mCountDownTimer != null) {
            mCountDownTimer.cancel();
            resetTimer();

        }

        SharedPreferences prefse = this.getActivity().getSharedPreferences("prefse", MODE_PRIVATE);
        SharedPreferences.Editor editor1 = prefse.edit();
        editor1.putLong("startTimeInMillis1", mStartTimeInMillis1);
        editor1.putLong("millisLeft1", mTimeLeftInMillis1);
        editor1.putBoolean("timerRunning1", mTimerRunning1);
        editor1.putLong("endTime1", mEndTime1);
        editor1.apply();
        if (mCountDownTimer1 != null) {
            mCountDownTimer1.cancel();
            resetTimer1();

        }
    }

    public void notific (){


        try {
            Intent intent = new Intent(getActivity(), AlarmReceiver.class);
            intent.putExtra("notificationId", notificationId);
            intent.putExtra("todo", "Time for a break. Take a walk and look outside for 20 seconds");

            PendingIntent alarmIntent = PendingIntent.getBroadcast(getActivity(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            AlarmManager alarm = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);

            long alarmStartTime = System.currentTimeMillis();

            alarm.set(AlarmManager.RTC_WAKEUP, alarmStartTime, alarmIntent);


        }catch (Exception e){
            Toast.makeText(getActivity(), "Exception", Toast.LENGTH_SHORT).show();
        }

    }

    public void notific1 (){


        try {
            Intent intent = new Intent(getActivity(), AlarmReceiver.class);
            intent.putExtra("notificationId", notificationId);
            intent.putExtra("todo", "Time for a break. Take a walk and look outside for 20 seconds");

            PendingIntent alarmIntent = PendingIntent.getBroadcast(getActivity(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            AlarmManager alarm = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);

            long alarmStartTime = System.currentTimeMillis();

            alarm.set(AlarmManager.RTC_WAKEUP, alarmStartTime, alarmIntent);


        }catch (Exception e){
            Toast.makeText(getActivity(), "Time for your Break", Toast.LENGTH_SHORT).show();
        }

    }
}
