# Reminder

1. Open the Reminder folder in Android SDK for deployment.
2. Once the application is running, enter you water goal and current intake.
3. Also set your break timer and exit the application to get notifications.